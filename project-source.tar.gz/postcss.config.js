export default {
  plugins: {
    tailwindcss: {},
  },
};
